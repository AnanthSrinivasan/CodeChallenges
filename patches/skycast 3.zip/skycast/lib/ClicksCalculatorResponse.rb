# It holds the response data required by the Navigator 

# steps - minimum steps taken to reach from source to target
# action - action through which minimum steps attained

class ClicksCalculatorResponse
	attr_accessor :clicks
	attr_accessor :action

	def initialize
		
	end
end